import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { EventEmitter, Component, ChangeDetectionStrategy, Input, Output, forwardRef, ViewChild, NgModule, Injectable } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i2 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i1$1 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i2$1 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i3 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3$2 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i1$2 from '@angular/material/paginator';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import * as i3$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i2$2 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i2$3 from '@angular/material/sort';
import { MatSort, MatSortModule } from '@angular/material/sort';
import * as i3$3 from '@angular/material/table';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { BehaviorSubject } from 'rxjs';

class DsAlertBannerComponent {
    constructor() {
        this.severity = 'info';
        this.dismissible = false;
        this.dismissed = new EventEmitter();
    }
    get icon() {
        switch (this.severity) {
            case 'critical':
                return 'error';
            case 'warning':
                return 'warning';
            case 'success':
                return 'check_circle';
            default:
                return 'info';
        }
    }
}
DsAlertBannerComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsAlertBannerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsAlertBannerComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsAlertBannerComponent, selector: "bofa-alert-banner", inputs: { severity: "severity", title: "title", dismissible: "dismissible" }, outputs: { dismissed: "dismissed" }, ngImport: i0, template: `
    <div class="bofa-alert" [ngClass]="'bofa-alert--' + severity" role="status">
      <mat-icon class="bofa-alert__icon">{{ icon }}</mat-icon>
      <div class="bofa-alert__body">
        <strong class="bofa-alert__title" *ngIf="title">{{ title }}</strong>
        <ng-content></ng-content>
      </div>
      <button
        mat-icon-button
        *ngIf="dismissible"
        class="bofa-alert__dismiss"
        aria-label="Dismiss notification"
        (click)="dismissed.emit()"
      >
        <mat-icon>close</mat-icon>
      </button>
    </div>
  `, isInline: true, styles: [".bofa-alert{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-left:4px solid currentColor;border-radius:4px}.bofa-alert--critical{color:#c8102e;background:#fdecee}.bofa-alert--warning{color:#8a5300;background:#fff6e5}.bofa-alert--info{color:#012169;background:#eaeef7}.bofa-alert--success{color:#1d6b3f;background:#eaf6ee}.bofa-alert__body{flex:1}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsAlertBannerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bofa-alert-banner', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="bofa-alert" [ngClass]="'bofa-alert--' + severity" role="status">
      <mat-icon class="bofa-alert__icon">{{ icon }}</mat-icon>
      <div class="bofa-alert__body">
        <strong class="bofa-alert__title" *ngIf="title">{{ title }}</strong>
        <ng-content></ng-content>
      </div>
      <button
        mat-icon-button
        *ngIf="dismissible"
        class="bofa-alert__dismiss"
        aria-label="Dismiss notification"
        (click)="dismissed.emit()"
      >
        <mat-icon>close</mat-icon>
      </button>
    </div>
  `, styles: [".bofa-alert{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-left:4px solid currentColor;border-radius:4px}.bofa-alert--critical{color:#c8102e;background:#fdecee}.bofa-alert--warning{color:#8a5300;background:#fff6e5}.bofa-alert--info{color:#012169;background:#eaeef7}.bofa-alert--success{color:#1d6b3f;background:#eaf6ee}.bofa-alert__body{flex:1}\n"] }]
        }], propDecorators: { severity: [{
                type: Input
            }], title: [{
                type: Input
            }], dismissible: [{
                type: Input
            }], dismissed: [{
                type: Output
            }] } });

class DsButtonComponent {
    constructor() {
        this.variant = 'primary';
        this.disabled = false;
        this.loading = false;
        this.pressed = new EventEmitter();
    }
    get materialColor() {
        switch (this.variant) {
            case 'danger':
                return 'warn';
            case 'secondary':
                return 'accent';
            default:
                return 'primary';
        }
    }
}
DsButtonComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsButtonComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsButtonComponent, selector: "bofa-button", inputs: { variant: "variant", disabled: "disabled", loading: "loading" }, outputs: { pressed: "pressed" }, ngImport: i0, template: `
    <button
      mat-raised-button
      class="bofa-button"
      [ngClass]="'bofa-button--' + variant"
      [color]="materialColor"
      [disabled]="disabled || loading"
      [attr.aria-busy]="loading"
      (click)="pressed.emit($event)"
    >
      <mat-spinner *ngIf="loading" class="bofa-button__spinner" diameter="18"></mat-spinner>
      <span class="bofa-button__label"><ng-content></ng-content></span>
    </button>
  `, isInline: true, styles: [".bofa-button__spinner{display:inline-block;margin-right:8px;vertical-align:middle}.bofa-button--danger{--bofa-button-bg: #c8102e}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { kind: "component", type: i3$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "diameter", "strokeWidth", "mode", "value"], exportAs: ["matProgressSpinner"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bofa-button', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <button
      mat-raised-button
      class="bofa-button"
      [ngClass]="'bofa-button--' + variant"
      [color]="materialColor"
      [disabled]="disabled || loading"
      [attr.aria-busy]="loading"
      (click)="pressed.emit($event)"
    >
      <mat-spinner *ngIf="loading" class="bofa-button__spinner" diameter="18"></mat-spinner>
      <span class="bofa-button__label"><ng-content></ng-content></span>
    </button>
  `, styles: [".bofa-button__spinner{display:inline-block;margin-right:8px;vertical-align:middle}.bofa-button--danger{--bofa-button-bg: #c8102e}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], disabled: [{
                type: Input
            }], loading: [{
                type: Input
            }], pressed: [{
                type: Output
            }] } });

class DsAccountCardComponent {
    constructor() {
        this.accountName = '';
        this.accountNumber = '';
        this.balance = 0;
        this.currencyCode = 'USD';
    }
    get maskedNumber() {
        const last4 = this.accountNumber.slice(-4);
        return last4 ? `•••• ${last4}` : '';
    }
}
DsAccountCardComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsAccountCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsAccountCardComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsAccountCardComponent, selector: "bofa-account-card", inputs: { accountName: "accountName", accountNumber: "accountNumber", balance: "balance", currencyCode: "currencyCode" }, ngImport: i0, template: `
    <mat-card class="bofa-account-card" appearance="outlined">
      <mat-card-header>
        <mat-card-title>{{ accountName }}</mat-card-title>
        <mat-card-subtitle>{{ maskedNumber }}</mat-card-subtitle>
      </mat-card-header>
      <mat-card-content>
        <p class="bofa-account-card__balance">{{ balance | currency : currencyCode }}</p>
        <ng-content></ng-content>
      </mat-card-content>
      <mat-card-actions align="end">
        <ng-content select="[cardActions]"></ng-content>
      </mat-card-actions>
    </mat-card>
  `, isInline: true, styles: [".bofa-account-card__balance{font-size:28px;font-weight:600;margin:8px 0 0}\n"], dependencies: [{ kind: "component", type: i1$1.MatCard, selector: "mat-card", exportAs: ["matCard"] }, { kind: "component", type: i1$1.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i1$1.MatCardContent, selector: "mat-card-content, [mat-card-content], [matCardContent]" }, { kind: "directive", type: i1$1.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "directive", type: i1$1.MatCardSubtitle, selector: "mat-card-subtitle, [mat-card-subtitle], [matCardSubtitle]" }, { kind: "directive", type: i1$1.MatCardActions, selector: "mat-card-actions", inputs: ["align"], exportAs: ["matCardActions"] }, { kind: "pipe", type: i1.CurrencyPipe, name: "currency" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsAccountCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bofa-account-card', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <mat-card class="bofa-account-card" appearance="outlined">
      <mat-card-header>
        <mat-card-title>{{ accountName }}</mat-card-title>
        <mat-card-subtitle>{{ maskedNumber }}</mat-card-subtitle>
      </mat-card-header>
      <mat-card-content>
        <p class="bofa-account-card__balance">{{ balance | currency : currencyCode }}</p>
        <ng-content></ng-content>
      </mat-card-content>
      <mat-card-actions align="end">
        <ng-content select="[cardActions]"></ng-content>
      </mat-card-actions>
    </mat-card>
  `, styles: [".bofa-account-card__balance{font-size:28px;font-weight:600;margin:8px 0 0}\n"] }]
        }], propDecorators: { accountName: [{
                type: Input
            }], accountNumber: [{
                type: Input
            }], balance: [{
                type: Input
            }], currencyCode: [{
                type: Input
            }] } });

class DsCurrencyInputComponent {
    constructor() {
        this.label = 'Amount';
        this.value = null;
        this.disabled = false;
        this.onChange = () => undefined;
        this.onTouched = () => undefined;
    }
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onInput(event) {
        const raw = event.target.value;
        this.value = raw === '' ? null : Number(raw);
        this.onChange(this.value);
    }
}
DsCurrencyInputComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsCurrencyInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsCurrencyInputComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsCurrencyInputComponent, selector: "bofa-currency-input", inputs: { label: "label", hint: "hint" }, providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => DsCurrencyInputComponent),
            multi: true,
        },
    ], ngImport: i0, template: `
    <mat-form-field appearance="outline" class="bofa-currency-input">
      <mat-label>{{ label }}</mat-label>
      <span matTextPrefix>$&nbsp;</span>
      <input
        matInput
        type="number"
        inputmode="decimal"
        [value]="value"
        [disabled]="disabled"
        [attr.aria-label]="label"
        (input)="onInput($event)"
        (blur)="onTouched()"
      />
      <mat-hint *ngIf="hint">{{ hint }}</mat-hint>
    </mat-form-field>
  `, isInline: true, styles: [".bofa-currency-input{width:100%}\n"], dependencies: [{ kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2$1.MatFormField, selector: "mat-form-field", inputs: ["color", "appearance", "hideRequiredMarker", "hintLabel", "floatLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2$1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2$1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i3$2.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsCurrencyInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bofa-currency-input', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => DsCurrencyInputComponent),
                            multi: true,
                        },
                    ], template: `
    <mat-form-field appearance="outline" class="bofa-currency-input">
      <mat-label>{{ label }}</mat-label>
      <span matTextPrefix>$&nbsp;</span>
      <input
        matInput
        type="number"
        inputmode="decimal"
        [value]="value"
        [disabled]="disabled"
        [attr.aria-label]="label"
        (input)="onInput($event)"
        (blur)="onTouched()"
      />
      <mat-hint *ngIf="hint">{{ hint }}</mat-hint>
    </mat-form-field>
  `, styles: [".bofa-currency-input{width:100%}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], hint: [{
                type: Input
            }] } });

/**
 * Statement period switcher. Still on the pre-MDC Material tabs implementation
 * inherited from the original build; the rest of the library has moved on.
 */
class DsStatementTabsComponent {
    constructor() {
        this.periods = [];
        this.selectedIndex = 0;
        this.periodChanged = new EventEmitter();
    }
}
DsStatementTabsComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsStatementTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsStatementTabsComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsStatementTabsComponent, selector: "bofa-statement-tabs", inputs: { periods: "periods", selectedIndex: "selectedIndex" }, outputs: { periodChanged: "periodChanged" }, ngImport: i0, template: `
    <mat-tab-group
      class="bofa-statement-tabs"
      [selectedIndex]="selectedIndex"
      (selectedIndexChange)="periodChanged.emit(periods[$event]?.periodId)"
    >
      <mat-tab *ngFor="let period of periods" [label]="period.label">
        <ng-template matTabContent>
          <p class="bofa-statement-tabs__count">
            {{ period.documentCount }} statement(s) available for {{ period.label }}
          </p>
          <ng-content></ng-content>
        </ng-template>
      </mat-tab>
    </mat-tab-group>
  `, isInline: true, styles: [".bofa-statement-tabs__count{padding:16px 8px;margin:0}\n"], dependencies: [{ kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: i2$2.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "disableRipple"], exportAs: ["matTabGroup"] }, { kind: "component", type: i2$2.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass"], exportAs: ["matTab"] }, { kind: "directive", type: i2$2.MatTabContent, selector: "[matTabContent]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsStatementTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bofa-statement-tabs', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <mat-tab-group
      class="bofa-statement-tabs"
      [selectedIndex]="selectedIndex"
      (selectedIndexChange)="periodChanged.emit(periods[$event]?.periodId)"
    >
      <mat-tab *ngFor="let period of periods" [label]="period.label">
        <ng-template matTabContent>
          <p class="bofa-statement-tabs__count">
            {{ period.documentCount }} statement(s) available for {{ period.label }}
          </p>
          <ng-content></ng-content>
        </ng-template>
      </mat-tab>
    </mat-tab-group>
  `, styles: [".bofa-statement-tabs__count{padding:16px 8px;margin:0}\n"] }]
        }], propDecorators: { periods: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], periodChanged: [{
                type: Output
            }] } });

class DsTransactionTableComponent {
    constructor() {
        this.transactions = [];
        this.displayedColumns = ['postedAt', 'description', 'category', 'amount'];
        this.dataSource = new MatTableDataSource([]);
    }
    ngOnChanges(changes) {
        if (changes['transactions']) {
            this.dataSource.data = this.transactions ?? [];
        }
    }
    ngAfterViewInit() {
        if (this.sort) {
            this.dataSource.sort = this.sort;
        }
        if (this.paginator) {
            this.dataSource.paginator = this.paginator;
        }
    }
}
DsTransactionTableComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsTransactionTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
DsTransactionTableComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.3.0", type: DsTransactionTableComponent, selector: "bofa-transaction-table", inputs: { transactions: "transactions", displayedColumns: "displayedColumns" }, viewQueries: [{ propertyName: "sort", first: true, predicate: MatSort, descendants: true }, { propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }], usesOnChanges: true, ngImport: i0, template: `
    <table mat-table [dataSource]="dataSource" matSort class="bofa-transaction-table">
      <ng-container matColumnDef="postedAt">
        <th mat-header-cell *matHeaderCellDef mat-sort-header>Date</th>
        <td mat-cell *matCellDef="let row">{{ row.postedAt | date : 'mediumDate' }}</td>
      </ng-container>

      <ng-container matColumnDef="description">
        <th mat-header-cell *matHeaderCellDef mat-sort-header>Description</th>
        <td mat-cell *matCellDef="let row">{{ row.description }}</td>
      </ng-container>

      <ng-container matColumnDef="category">
        <th mat-header-cell *matHeaderCellDef>Category</th>
        <td mat-cell *matCellDef="let row">{{ row.category }}</td>
      </ng-container>

      <ng-container matColumnDef="amount">
        <th mat-header-cell *matHeaderCellDef mat-sort-header class="bofa-cell--numeric">Amount</th>
        <td mat-cell *matCellDef="let row" class="bofa-cell--numeric">
          {{ row.amount | currency }}
        </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
      <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
    </table>
    <mat-paginator [pageSizeOptions]="[10, 25, 50]" showFirstLastButtons></mat-paginator>
  `, isInline: true, styles: [".bofa-transaction-table{width:100%}.bofa-cell--numeric{text-align:right}\n"], dependencies: [{ kind: "component", type: i1$2.MatPaginator, selector: "mat-paginator", inputs: ["disabled"], exportAs: ["matPaginator"] }, { kind: "directive", type: i2$3.MatSort, selector: "[matSort]", inputs: ["matSortDisabled", "matSortActive", "matSortStart", "matSortDirection", "matSortDisableClear"], outputs: ["matSortChange"], exportAs: ["matSort"] }, { kind: "component", type: i2$3.MatSortHeader, selector: "[mat-sort-header]", inputs: ["disabled", "mat-sort-header", "arrowPosition", "start", "sortActionDescription", "disableClear"], exportAs: ["matSortHeader"] }, { kind: "component", type: i3$3.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i3$3.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i3$3.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i3$3.MatColumnDef, selector: "[matColumnDef]", inputs: ["sticky", "matColumnDef"] }, { kind: "directive", type: i3$3.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i3$3.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i3$3.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i3$3.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i3$3.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i3$3.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "pipe", type: i1.CurrencyPipe, name: "currency" }, { kind: "pipe", type: i1.DatePipe, name: "date" }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsTransactionTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bofa-transaction-table', template: `
    <table mat-table [dataSource]="dataSource" matSort class="bofa-transaction-table">
      <ng-container matColumnDef="postedAt">
        <th mat-header-cell *matHeaderCellDef mat-sort-header>Date</th>
        <td mat-cell *matCellDef="let row">{{ row.postedAt | date : 'mediumDate' }}</td>
      </ng-container>

      <ng-container matColumnDef="description">
        <th mat-header-cell *matHeaderCellDef mat-sort-header>Description</th>
        <td mat-cell *matCellDef="let row">{{ row.description }}</td>
      </ng-container>

      <ng-container matColumnDef="category">
        <th mat-header-cell *matHeaderCellDef>Category</th>
        <td mat-cell *matCellDef="let row">{{ row.category }}</td>
      </ng-container>

      <ng-container matColumnDef="amount">
        <th mat-header-cell *matHeaderCellDef mat-sort-header class="bofa-cell--numeric">Amount</th>
        <td mat-cell *matCellDef="let row" class="bofa-cell--numeric">
          {{ row.amount | currency }}
        </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
      <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
    </table>
    <mat-paginator [pageSizeOptions]="[10, 25, 50]" showFirstLastButtons></mat-paginator>
  `, styles: [".bofa-transaction-table{width:100%}.bofa-cell--numeric{text-align:right}\n"] }]
        }], propDecorators: { transactions: [{
                type: Input
            }], displayedColumns: [{
                type: Input
            }], sort: [{
                type: ViewChild,
                args: [MatSort]
            }], paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }] } });

const COMPONENTS = [
    DsAlertBannerComponent,
    DsButtonComponent,
    DsAccountCardComponent,
    DsCurrencyInputComponent,
    DsStatementTabsComponent,
    DsTransactionTableComponent,
];
class DsModule {
}
DsModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
DsModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "14.3.0", ngImport: i0, type: DsModule, declarations: [DsAlertBannerComponent,
        DsButtonComponent,
        DsAccountCardComponent,
        DsCurrencyInputComponent,
        DsStatementTabsComponent,
        DsTransactionTableComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatCardModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatPaginatorModule,
        MatTabsModule,
        MatProgressSpinnerModule,
        MatSortModule,
        MatTableModule], exports: [DsAlertBannerComponent,
        DsButtonComponent,
        DsAccountCardComponent,
        DsCurrencyInputComponent,
        DsStatementTabsComponent,
        DsTransactionTableComponent] });
DsModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsModule, imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatCardModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatPaginatorModule,
        MatTabsModule,
        MatProgressSpinnerModule,
        MatSortModule,
        MatTableModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [...COMPONENTS],
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatButtonModule,
                        MatCardModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatPaginatorModule,
                        MatTabsModule,
                        MatProgressSpinnerModule,
                        MatSortModule,
                        MatTableModule,
                    ],
                    exports: [...COMPONENTS],
                }]
        }] });

class DsThemeService {
    constructor() {
        this.mode$ = new BehaviorSubject('light');
    }
    get changes() {
        return this.mode$.asObservable();
    }
    get current() {
        return this.mode$.value;
    }
    setMode(mode) {
        const root = document.documentElement;
        root.classList.remove('bofa-theme--light', 'bofa-theme--dark', 'bofa-theme--high-contrast');
        root.classList.add(`bofa-theme--${mode}`);
        this.mode$.next(mode);
    }
}
DsThemeService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
DsThemeService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsThemeService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.3.0", ngImport: i0, type: DsThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Public API surface of @bofa/ds
 *
 * Consumed by downstream retail banking applications. Anything exported here is a
 * compatibility contract: removals and signature changes break consumer builds.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DsAccountCardComponent, DsAlertBannerComponent, DsButtonComponent, DsCurrencyInputComponent, DsModule, DsStatementTabsComponent, DsThemeService, DsTransactionTableComponent };
//# sourceMappingURL=bofa-ds.mjs.map
