import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare type DsAlertSeverity = 'info' | 'warning' | 'critical' | 'success';
export declare class DsAlertBannerComponent {
    severity: DsAlertSeverity;
    title?: string;
    dismissible: boolean;
    dismissed: EventEmitter<void>;
    get icon(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsAlertBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsAlertBannerComponent, "bofa-alert-banner", never, { "severity": "severity"; "title": "title"; "dismissible": "dismissible"; }, { "dismissed": "dismissed"; }, never, ["*"], false>;
}
