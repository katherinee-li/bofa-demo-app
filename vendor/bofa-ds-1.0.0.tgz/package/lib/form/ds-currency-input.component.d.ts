import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class DsCurrencyInputComponent implements ControlValueAccessor {
    label: string;
    hint?: string;
    value: number | null;
    disabled: boolean;
    private onChange;
    onTouched: () => void;
    writeValue(value: number | null): void;
    registerOnChange(fn: (value: number | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onInput(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsCurrencyInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsCurrencyInputComponent, "bofa-currency-input", never, { "label": "label"; "hint": "hint"; }, {}, never, never, false>;
}
