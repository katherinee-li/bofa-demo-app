import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export interface DsStatementPeriod {
    label: string;
    periodId: string;
    documentCount: number;
}
/**
 * Statement period switcher. Still on the pre-MDC Material tabs implementation
 * inherited from the original build; the rest of the library has moved on.
 */
export declare class DsStatementTabsComponent {
    periods: DsStatementPeriod[];
    selectedIndex: number;
    periodChanged: EventEmitter<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsStatementTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsStatementTabsComponent, "bofa-statement-tabs", never, { "periods": "periods"; "selectedIndex": "selectedIndex"; }, { "periodChanged": "periodChanged"; }, never, ["*"], false>;
}
