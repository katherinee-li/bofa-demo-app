import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { EventEmitter, Component, ChangeDetectionStrategy, Input, Output, forwardRef, ViewChild, NgModule, Injectable } from '@angular/core';
import { NG_VALUE_ACCESSOR, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i2 from '@angular/material/legacy-button';
import { MatLegacyButtonModule } from '@angular/material/legacy-button';
import * as i1$1 from '@angular/material/legacy-card';
import { MatLegacyCardModule } from '@angular/material/legacy-card';
import * as i2$1 from '@angular/material/legacy-form-field';
import { MatLegacyFormFieldModule } from '@angular/material/legacy-form-field';
import * as i3 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3$2 from '@angular/material/legacy-input';
import { MatLegacyInputModule } from '@angular/material/legacy-input';
import * as i1$2 from '@angular/material/legacy-paginator';
import { MatLegacyPaginator, MatLegacyPaginatorModule } from '@angular/material/legacy-paginator';
import * as i3$1 from '@angular/material/legacy-progress-spinner';
import { MatLegacyProgressSpinnerModule } from '@angular/material/legacy-progress-spinner';
import * as i2$2 from '@angular/material/legacy-tabs';
import { MatLegacyTabsModule } from '@angular/material/legacy-tabs';
import * as i2$3 from '@angular/material/sort';
import { MatSort, MatSortModule } from '@angular/material/sort';
import * as i3$3 from '@angular/material/legacy-table';
import { MatLegacyTableDataSource, MatLegacyTableModule } from '@angular/material/legacy-table';
import { BehaviorSubject } from 'rxjs';

function DsAlertBannerComponent_strong_4_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "strong", 5);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(ctx_r0.title);
    }
}
function DsAlertBannerComponent_button_6_Template(rf, ctx) {
    if (rf & 1) {
        const _r3 = i0.ɵɵgetCurrentView();
        i0.ɵɵelementStart(0, "button", 6);
        i0.ɵɵlistener("click", function DsAlertBannerComponent_button_6_Template_button_click_0_listener() { i0.ɵɵrestoreView(_r3); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.dismissed.emit()); });
        i0.ɵɵelementStart(1, "mat-icon");
        i0.ɵɵtext(2, "close");
        i0.ɵɵelementEnd()();
    }
}
const _c0$4 = ["*"];
class DsAlertBannerComponent {
    constructor() {
        this.severity = 'info';
        this.dismissible = false;
        this.dismissed = new EventEmitter();
    }
    get icon() {
        switch (this.severity) {
            case 'critical':
                return 'error';
            case 'warning':
                return 'warning';
            case 'success':
                return 'check_circle';
            default:
                return 'info';
        }
    }
}
DsAlertBannerComponent.ɵfac = function DsAlertBannerComponent_Factory(t) { return new (t || DsAlertBannerComponent)(); };
DsAlertBannerComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DsAlertBannerComponent, selectors: [["bofa-alert-banner"]], inputs: { severity: "severity", title: "title", dismissible: "dismissible" }, outputs: { dismissed: "dismissed" }, ngContentSelectors: _c0$4, decls: 7, vars: 4, consts: [["role", "status", 1, "bofa-alert", 3, "ngClass"], [1, "bofa-alert__icon"], [1, "bofa-alert__body"], ["class", "bofa-alert__title", 4, "ngIf"], ["mat-icon-button", "", "class", "bofa-alert__dismiss", "aria-label", "Dismiss notification", 3, "click", 4, "ngIf"], [1, "bofa-alert__title"], ["mat-icon-button", "", "aria-label", "Dismiss notification", 1, "bofa-alert__dismiss", 3, "click"]], template: function DsAlertBannerComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "div", 0)(1, "mat-icon", 1);
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "div", 2);
            i0.ɵɵtemplate(4, DsAlertBannerComponent_strong_4_Template, 2, 1, "strong", 3);
            i0.ɵɵprojection(5);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(6, DsAlertBannerComponent_button_6_Template, 3, 0, "button", 4);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngClass", "bofa-alert--" + ctx.severity);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.icon);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.title);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.dismissible);
        }
    }, dependencies: [i1.NgClass, i1.NgIf, i2.MatLegacyButton, i3.MatIcon], styles: [".bofa-alert[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-left:4px solid currentColor;border-radius:4px}.bofa-alert--critical[_ngcontent-%COMP%]{color:#c8102e;background:#fdecee}.bofa-alert--warning[_ngcontent-%COMP%]{color:#8a5300;background:#fff6e5}.bofa-alert--info[_ngcontent-%COMP%]{color:#012169;background:#eaeef7}.bofa-alert--success[_ngcontent-%COMP%]{color:#1d6b3f;background:#eaf6ee}.bofa-alert__body[_ngcontent-%COMP%]{flex:1}"], changeDetection: 0 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DsAlertBannerComponent, [{
            type: Component,
            args: [{ selector: 'bofa-alert-banner', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="bofa-alert" [ngClass]="'bofa-alert--' + severity" role="status">
      <mat-icon class="bofa-alert__icon">{{ icon }}</mat-icon>
      <div class="bofa-alert__body">
        <strong class="bofa-alert__title" *ngIf="title">{{ title }}</strong>
        <ng-content></ng-content>
      </div>
      <button
        mat-icon-button
        *ngIf="dismissible"
        class="bofa-alert__dismiss"
        aria-label="Dismiss notification"
        (click)="dismissed.emit()"
      >
        <mat-icon>close</mat-icon>
      </button>
    </div>
  `, styles: [".bofa-alert{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border-left:4px solid currentColor;border-radius:4px}.bofa-alert--critical{color:#c8102e;background:#fdecee}.bofa-alert--warning{color:#8a5300;background:#fff6e5}.bofa-alert--info{color:#012169;background:#eaeef7}.bofa-alert--success{color:#1d6b3f;background:#eaf6ee}.bofa-alert__body{flex:1}\n"] }]
        }], null, { severity: [{
                type: Input
            }], title: [{
                type: Input
            }], dismissible: [{
                type: Input
            }], dismissed: [{
                type: Output
            }] });
})();

function DsButtonComponent_mat_spinner_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "mat-spinner", 3);
    }
}
const _c0$3 = ["*"];
class DsButtonComponent {
    constructor() {
        this.variant = 'primary';
        this.disabled = false;
        this.loading = false;
        this.pressed = new EventEmitter();
    }
    get materialColor() {
        switch (this.variant) {
            case 'danger':
                return 'warn';
            case 'secondary':
                return 'accent';
            default:
                return 'primary';
        }
    }
}
DsButtonComponent.ɵfac = function DsButtonComponent_Factory(t) { return new (t || DsButtonComponent)(); };
DsButtonComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DsButtonComponent, selectors: [["bofa-button"]], inputs: { variant: "variant", disabled: "disabled", loading: "loading" }, outputs: { pressed: "pressed" }, ngContentSelectors: _c0$3, decls: 4, vars: 5, consts: [["mat-raised-button", "", 1, "bofa-button", 3, "ngClass", "color", "disabled", "click"], ["class", "bofa-button__spinner", "diameter", "18", 4, "ngIf"], [1, "bofa-button__label"], ["diameter", "18", 1, "bofa-button__spinner"]], template: function DsButtonComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "button", 0);
            i0.ɵɵlistener("click", function DsButtonComponent_Template_button_click_0_listener($event) { return ctx.pressed.emit($event); });
            i0.ɵɵtemplate(1, DsButtonComponent_mat_spinner_1_Template, 1, 0, "mat-spinner", 1);
            i0.ɵɵelementStart(2, "span", 2);
            i0.ɵɵprojection(3);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵproperty("ngClass", "bofa-button--" + ctx.variant)("color", ctx.materialColor)("disabled", ctx.disabled || ctx.loading);
            i0.ɵɵattribute("aria-busy", ctx.loading);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.loading);
        }
    }, dependencies: [i1.NgClass, i1.NgIf, i2.MatLegacyButton, i3$1.MatLegacyProgressSpinner], styles: [".bofa-button__spinner[_ngcontent-%COMP%]{display:inline-block;margin-right:8px;vertical-align:middle}.bofa-button--danger[_ngcontent-%COMP%]{--bofa-button-bg: #c8102e}"], changeDetection: 0 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DsButtonComponent, [{
            type: Component,
            args: [{ selector: 'bofa-button', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <button
      mat-raised-button
      class="bofa-button"
      [ngClass]="'bofa-button--' + variant"
      [color]="materialColor"
      [disabled]="disabled || loading"
      [attr.aria-busy]="loading"
      (click)="pressed.emit($event)"
    >
      <mat-spinner *ngIf="loading" class="bofa-button__spinner" diameter="18"></mat-spinner>
      <span class="bofa-button__label"><ng-content></ng-content></span>
    </button>
  `, styles: [".bofa-button__spinner{display:inline-block;margin-right:8px;vertical-align:middle}.bofa-button--danger{--bofa-button-bg: #c8102e}\n"] }]
        }], null, { variant: [{
                type: Input
            }], disabled: [{
                type: Input
            }], loading: [{
                type: Input
            }], pressed: [{
                type: Output
            }] });
})();

const _c0$2 = ["*", [["", "cardActions", ""]]];
const _c1 = ["*", "[cardActions]"];
class DsAccountCardComponent {
    constructor() {
        this.accountName = '';
        this.accountNumber = '';
        this.balance = 0;
        this.currencyCode = 'USD';
    }
    get maskedNumber() {
        const last4 = this.accountNumber.slice(-4);
        return last4 ? `•••• ${last4}` : '';
    }
}
DsAccountCardComponent.ɵfac = function DsAccountCardComponent_Factory(t) { return new (t || DsAccountCardComponent)(); };
DsAccountCardComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DsAccountCardComponent, selectors: [["bofa-account-card"]], inputs: { accountName: "accountName", accountNumber: "accountNumber", balance: "balance", currencyCode: "currencyCode" }, ngContentSelectors: _c1, decls: 13, vars: 6, consts: [["appearance", "outlined", 1, "bofa-account-card"], [1, "bofa-account-card__balance"], ["align", "end"]], template: function DsAccountCardComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵprojectionDef(_c0$2);
            i0.ɵɵelementStart(0, "mat-card", 0)(1, "mat-card-header")(2, "mat-card-title");
            i0.ɵɵtext(3);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "mat-card-subtitle");
            i0.ɵɵtext(5);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(6, "mat-card-content")(7, "p", 1);
            i0.ɵɵtext(8);
            i0.ɵɵpipe(9, "currency");
            i0.ɵɵelementEnd();
            i0.ɵɵprojection(10);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(11, "mat-card-actions", 2);
            i0.ɵɵprojection(12, 1);
            i0.ɵɵelementEnd()();
        }
        if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(ctx.accountName);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.maskedNumber);
            i0.ɵɵadvance(3);
            i0.ɵɵtextInterpolate(i0.ɵɵpipeBind2(9, 3, ctx.balance, ctx.currencyCode));
        }
    }, dependencies: [i1$1.MatLegacyCard, i1$1.MatLegacyCardHeader, i1$1.MatLegacyCardContent, i1$1.MatLegacyCardTitle, i1$1.MatLegacyCardSubtitle, i1$1.MatLegacyCardActions, i1.CurrencyPipe], styles: [".bofa-account-card__balance[_ngcontent-%COMP%]{font-size:28px;font-weight:600;margin:8px 0 0}"], changeDetection: 0 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DsAccountCardComponent, [{
            type: Component,
            args: [{ selector: 'bofa-account-card', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <mat-card class="bofa-account-card" appearance="outlined">
      <mat-card-header>
        <mat-card-title>{{ accountName }}</mat-card-title>
        <mat-card-subtitle>{{ maskedNumber }}</mat-card-subtitle>
      </mat-card-header>
      <mat-card-content>
        <p class="bofa-account-card__balance">{{ balance | currency : currencyCode }}</p>
        <ng-content></ng-content>
      </mat-card-content>
      <mat-card-actions align="end">
        <ng-content select="[cardActions]"></ng-content>
      </mat-card-actions>
    </mat-card>
  `, styles: [".bofa-account-card__balance{font-size:28px;font-weight:600;margin:8px 0 0}\n"] }]
        }], null, { accountName: [{
                type: Input
            }], accountNumber: [{
                type: Input
            }], balance: [{
                type: Input
            }], currencyCode: [{
                type: Input
            }] });
})();

function DsCurrencyInputComponent_mat_hint_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-hint");
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const ctx_r0 = i0.ɵɵnextContext();
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(ctx_r0.hint);
    }
}
class DsCurrencyInputComponent {
    constructor() {
        this.label = 'Amount';
        this.value = null;
        this.disabled = false;
        this.onChange = () => undefined;
        this.onTouched = () => undefined;
    }
    writeValue(value) {
        this.value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    onInput(event) {
        const raw = event.target.value;
        this.value = raw === '' ? null : Number(raw);
        this.onChange(this.value);
    }
}
DsCurrencyInputComponent.ɵfac = function DsCurrencyInputComponent_Factory(t) { return new (t || DsCurrencyInputComponent)(); };
DsCurrencyInputComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DsCurrencyInputComponent, selectors: [["bofa-currency-input"]], inputs: { label: "label", hint: "hint" }, features: [i0.ɵɵProvidersFeature([
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => DsCurrencyInputComponent),
                multi: true,
            },
        ])], decls: 7, vars: 5, consts: [["appearance", "outline", 1, "bofa-currency-input"], ["matTextPrefix", ""], ["matInput", "", "type", "number", "inputmode", "decimal", 3, "value", "disabled", "input", "blur"], [4, "ngIf"]], template: function DsCurrencyInputComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "mat-form-field", 0)(1, "mat-label");
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(3, "span", 1);
            i0.ɵɵtext(4, "$\u00A0");
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(5, "input", 2);
            i0.ɵɵlistener("input", function DsCurrencyInputComponent_Template_input_input_5_listener($event) { return ctx.onInput($event); })("blur", function DsCurrencyInputComponent_Template_input_blur_5_listener() { return ctx.onTouched(); });
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(6, DsCurrencyInputComponent_mat_hint_6_Template, 2, 1, "mat-hint", 3);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.label);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("value", ctx.value)("disabled", ctx.disabled);
            i0.ɵɵattribute("aria-label", ctx.label);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngIf", ctx.hint);
        }
    }, dependencies: [i1.NgIf, i2$1.MatLegacyFormField, i2$1.MatLegacyHint, i2$1.MatLegacyLabel, i3$2.MatLegacyInput], styles: [".bofa-currency-input[_ngcontent-%COMP%]{width:100%}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DsCurrencyInputComponent, [{
            type: Component,
            args: [{ selector: 'bofa-currency-input', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => DsCurrencyInputComponent),
                            multi: true,
                        },
                    ], template: `
    <mat-form-field appearance="outline" class="bofa-currency-input">
      <mat-label>{{ label }}</mat-label>
      <span matTextPrefix>$&nbsp;</span>
      <input
        matInput
        type="number"
        inputmode="decimal"
        [value]="value"
        [disabled]="disabled"
        [attr.aria-label]="label"
        (input)="onInput($event)"
        (blur)="onTouched()"
      />
      <mat-hint *ngIf="hint">{{ hint }}</mat-hint>
    </mat-form-field>
  `, styles: [".bofa-currency-input{width:100%}\n"] }]
        }], null, { label: [{
                type: Input
            }], hint: [{
                type: Input
            }] });
})();

function DsStatementTabsComponent_mat_tab_1_ng_template_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "p", 4);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
        i0.ɵɵprojection(2);
    }
    if (rf & 2) {
        const period_r1 = i0.ɵɵnextContext().$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate2(" ", period_r1.documentCount, " statement(s) available for ", period_r1.label, " ");
    }
}
function DsStatementTabsComponent_mat_tab_1_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "mat-tab", 2);
        i0.ɵɵtemplate(1, DsStatementTabsComponent_mat_tab_1_ng_template_1_Template, 3, 2, "ng-template", 3);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const period_r1 = ctx.$implicit;
        i0.ɵɵproperty("label", period_r1.label);
    }
}
const _c0$1 = ["*"];
/**
 * Statement period switcher. Still on the pre-MDC Material tabs implementation
 * inherited from the original build; the rest of the library has moved on.
 */
class DsStatementTabsComponent {
    constructor() {
        this.periods = [];
        this.selectedIndex = 0;
        this.periodChanged = new EventEmitter();
    }
}
DsStatementTabsComponent.ɵfac = function DsStatementTabsComponent_Factory(t) { return new (t || DsStatementTabsComponent)(); };
DsStatementTabsComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DsStatementTabsComponent, selectors: [["bofa-statement-tabs"]], inputs: { periods: "periods", selectedIndex: "selectedIndex" }, outputs: { periodChanged: "periodChanged" }, ngContentSelectors: _c0$1, decls: 2, vars: 2, consts: [[1, "bofa-statement-tabs", 3, "selectedIndex", "selectedIndexChange"], [3, "label", 4, "ngFor", "ngForOf"], [3, "label"], ["matTabContent", ""], [1, "bofa-statement-tabs__count"]], template: function DsStatementTabsComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵprojectionDef();
            i0.ɵɵelementStart(0, "mat-tab-group", 0);
            i0.ɵɵlistener("selectedIndexChange", function DsStatementTabsComponent_Template_mat_tab_group_selectedIndexChange_0_listener($event) { return ctx.periodChanged.emit(ctx.periods[$event] == null ? null : ctx.periods[$event].periodId); });
            i0.ɵɵtemplate(1, DsStatementTabsComponent_mat_tab_1_Template, 2, 1, "mat-tab", 1);
            i0.ɵɵelementEnd();
        }
        if (rf & 2) {
            i0.ɵɵproperty("selectedIndex", ctx.selectedIndex);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("ngForOf", ctx.periods);
        }
    }, dependencies: [i1.NgForOf, i2$2.MatLegacyTabGroup, i2$2.MatLegacyTab, i2$2.MatLegacyTabContent], styles: [".bofa-statement-tabs__count[_ngcontent-%COMP%]{padding:16px 8px;margin:0}"], changeDetection: 0 });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DsStatementTabsComponent, [{
            type: Component,
            args: [{ selector: 'bofa-statement-tabs', changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <mat-tab-group
      class="bofa-statement-tabs"
      [selectedIndex]="selectedIndex"
      (selectedIndexChange)="periodChanged.emit(periods[$event]?.periodId)"
    >
      <mat-tab *ngFor="let period of periods" [label]="period.label">
        <ng-template matTabContent>
          <p class="bofa-statement-tabs__count">
            {{ period.documentCount }} statement(s) available for {{ period.label }}
          </p>
          <ng-content></ng-content>
        </ng-template>
      </mat-tab>
    </mat-tab-group>
  `, styles: [".bofa-statement-tabs__count{padding:16px 8px;margin:0}\n"] }]
        }], null, { periods: [{
                type: Input
            }], selectedIndex: [{
                type: Input
            }], periodChanged: [{
                type: Output
            }] });
})();

function DsTransactionTableComponent_th_2_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "th", 13);
        i0.ɵɵtext(1, "Date");
        i0.ɵɵelementEnd();
    }
}
function DsTransactionTableComponent_td_3_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "td", 14);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "date");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const row_r10 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(i0.ɵɵpipeBind2(2, 1, row_r10.postedAt, "mediumDate"));
    }
}
function DsTransactionTableComponent_th_5_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "th", 13);
        i0.ɵɵtext(1, "Description");
        i0.ɵɵelementEnd();
    }
}
function DsTransactionTableComponent_td_6_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "td", 14);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const row_r11 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(row_r11.description);
    }
}
function DsTransactionTableComponent_th_8_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "th", 15);
        i0.ɵɵtext(1, "Category");
        i0.ɵɵelementEnd();
    }
}
function DsTransactionTableComponent_td_9_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "td", 14);
        i0.ɵɵtext(1);
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const row_r12 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate(row_r12.category);
    }
}
function DsTransactionTableComponent_th_11_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "th", 16);
        i0.ɵɵtext(1, "Amount");
        i0.ɵɵelementEnd();
    }
}
function DsTransactionTableComponent_td_12_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelementStart(0, "td", 17);
        i0.ɵɵtext(1);
        i0.ɵɵpipe(2, "currency");
        i0.ɵɵelementEnd();
    }
    if (rf & 2) {
        const row_r13 = ctx.$implicit;
        i0.ɵɵadvance(1);
        i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(2, 1, row_r13.amount), " ");
    }
}
function DsTransactionTableComponent_tr_13_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "tr", 18);
    }
}
function DsTransactionTableComponent_tr_14_Template(rf, ctx) {
    if (rf & 1) {
        i0.ɵɵelement(0, "tr", 19);
    }
}
const _c0 = function () { return [10, 25, 50]; };
class DsTransactionTableComponent {
    constructor() {
        this.transactions = [];
        this.displayedColumns = ['postedAt', 'description', 'category', 'amount'];
        this.dataSource = new MatLegacyTableDataSource([]);
    }
    ngOnChanges(changes) {
        var _a;
        if (changes['transactions']) {
            this.dataSource.data = (_a = this.transactions) !== null && _a !== void 0 ? _a : [];
        }
    }
    ngAfterViewInit() {
        if (this.sort) {
            this.dataSource.sort = this.sort;
        }
        if (this.paginator) {
            this.dataSource.paginator = this.paginator;
        }
    }
}
DsTransactionTableComponent.ɵfac = function DsTransactionTableComponent_Factory(t) { return new (t || DsTransactionTableComponent)(); };
DsTransactionTableComponent.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: DsTransactionTableComponent, selectors: [["bofa-transaction-table"]], viewQuery: function DsTransactionTableComponent_Query(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵviewQuery(MatSort, 5);
            i0.ɵɵviewQuery(MatLegacyPaginator, 5);
        }
        if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.sort = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.paginator = _t.first);
        }
    }, inputs: { transactions: "transactions", displayedColumns: "displayedColumns" }, features: [i0.ɵɵNgOnChangesFeature], decls: 16, vars: 5, consts: [["mat-table", "", "matSort", "", 1, "bofa-transaction-table", 3, "dataSource"], ["matColumnDef", "postedAt"], ["mat-header-cell", "", "mat-sort-header", "", 4, "matHeaderCellDef"], ["mat-cell", "", 4, "matCellDef"], ["matColumnDef", "description"], ["matColumnDef", "category"], ["mat-header-cell", "", 4, "matHeaderCellDef"], ["matColumnDef", "amount"], ["mat-header-cell", "", "mat-sort-header", "", "class", "bofa-cell--numeric", 4, "matHeaderCellDef"], ["mat-cell", "", "class", "bofa-cell--numeric", 4, "matCellDef"], ["mat-header-row", "", 4, "matHeaderRowDef"], ["mat-row", "", 4, "matRowDef", "matRowDefColumns"], ["showFirstLastButtons", "", 3, "pageSizeOptions"], ["mat-header-cell", "", "mat-sort-header", ""], ["mat-cell", ""], ["mat-header-cell", ""], ["mat-header-cell", "", "mat-sort-header", "", 1, "bofa-cell--numeric"], ["mat-cell", "", 1, "bofa-cell--numeric"], ["mat-header-row", ""], ["mat-row", ""]], template: function DsTransactionTableComponent_Template(rf, ctx) {
        if (rf & 1) {
            i0.ɵɵelementStart(0, "table", 0);
            i0.ɵɵelementContainerStart(1, 1);
            i0.ɵɵtemplate(2, DsTransactionTableComponent_th_2_Template, 2, 0, "th", 2);
            i0.ɵɵtemplate(3, DsTransactionTableComponent_td_3_Template, 3, 4, "td", 3);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(4, 4);
            i0.ɵɵtemplate(5, DsTransactionTableComponent_th_5_Template, 2, 0, "th", 2);
            i0.ɵɵtemplate(6, DsTransactionTableComponent_td_6_Template, 2, 1, "td", 3);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(7, 5);
            i0.ɵɵtemplate(8, DsTransactionTableComponent_th_8_Template, 2, 0, "th", 6);
            i0.ɵɵtemplate(9, DsTransactionTableComponent_td_9_Template, 2, 1, "td", 3);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵelementContainerStart(10, 7);
            i0.ɵɵtemplate(11, DsTransactionTableComponent_th_11_Template, 2, 0, "th", 8);
            i0.ɵɵtemplate(12, DsTransactionTableComponent_td_12_Template, 3, 3, "td", 9);
            i0.ɵɵelementContainerEnd();
            i0.ɵɵtemplate(13, DsTransactionTableComponent_tr_13_Template, 1, 0, "tr", 10);
            i0.ɵɵtemplate(14, DsTransactionTableComponent_tr_14_Template, 1, 0, "tr", 11);
            i0.ɵɵelementEnd();
            i0.ɵɵelement(15, "mat-paginator", 12);
        }
        if (rf & 2) {
            i0.ɵɵproperty("dataSource", ctx.dataSource);
            i0.ɵɵadvance(13);
            i0.ɵɵproperty("matHeaderRowDef", ctx.displayedColumns);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("matRowDefColumns", ctx.displayedColumns);
            i0.ɵɵadvance(1);
            i0.ɵɵproperty("pageSizeOptions", i0.ɵɵpureFunction0(4, _c0));
        }
    }, dependencies: [i1$2.MatLegacyPaginator, i2$3.MatSort, i2$3.MatSortHeader, i3$3.MatLegacyTable, i3$3.MatLegacyHeaderCellDef, i3$3.MatLegacyHeaderRowDef, i3$3.MatLegacyColumnDef, i3$3.MatLegacyCellDef, i3$3.MatLegacyRowDef, i3$3.MatLegacyHeaderCell, i3$3.MatLegacyCell, i3$3.MatLegacyHeaderRow, i3$3.MatLegacyRow, i1.CurrencyPipe, i1.DatePipe], styles: [".bofa-transaction-table[_ngcontent-%COMP%]{width:100%}.bofa-cell--numeric[_ngcontent-%COMP%]{text-align:right}"] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DsTransactionTableComponent, [{
            type: Component,
            args: [{ selector: 'bofa-transaction-table', template: `
    <table mat-table [dataSource]="dataSource" matSort class="bofa-transaction-table">
      <ng-container matColumnDef="postedAt">
        <th mat-header-cell *matHeaderCellDef mat-sort-header>Date</th>
        <td mat-cell *matCellDef="let row">{{ row.postedAt | date : 'mediumDate' }}</td>
      </ng-container>

      <ng-container matColumnDef="description">
        <th mat-header-cell *matHeaderCellDef mat-sort-header>Description</th>
        <td mat-cell *matCellDef="let row">{{ row.description }}</td>
      </ng-container>

      <ng-container matColumnDef="category">
        <th mat-header-cell *matHeaderCellDef>Category</th>
        <td mat-cell *matCellDef="let row">{{ row.category }}</td>
      </ng-container>

      <ng-container matColumnDef="amount">
        <th mat-header-cell *matHeaderCellDef mat-sort-header class="bofa-cell--numeric">Amount</th>
        <td mat-cell *matCellDef="let row" class="bofa-cell--numeric">
          {{ row.amount | currency }}
        </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
      <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
    </table>
    <mat-paginator [pageSizeOptions]="[10, 25, 50]" showFirstLastButtons></mat-paginator>
  `, styles: [".bofa-transaction-table{width:100%}.bofa-cell--numeric{text-align:right}\n"] }]
        }], null, { transactions: [{
                type: Input
            }], displayedColumns: [{
                type: Input
            }], sort: [{
                type: ViewChild,
                args: [MatSort]
            }], paginator: [{
                type: ViewChild,
                args: [MatLegacyPaginator]
            }] });
})();

const COMPONENTS = [
    DsAlertBannerComponent,
    DsButtonComponent,
    DsAccountCardComponent,
    DsCurrencyInputComponent,
    DsStatementTabsComponent,
    DsTransactionTableComponent,
];
class DsModule {
}
DsModule.ɵfac = function DsModule_Factory(t) { return new (t || DsModule)(); };
DsModule.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: DsModule });
DsModule.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatLegacyButtonModule,
        MatLegacyCardModule,
        MatLegacyFormFieldModule,
        MatIconModule,
        MatLegacyInputModule,
        MatLegacyPaginatorModule,
        MatLegacyTabsModule,
        MatLegacyProgressSpinnerModule,
        MatSortModule,
        MatLegacyTableModule] });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DsModule, [{
            type: NgModule,
            args: [{
                    declarations: [...COMPONENTS],
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        MatLegacyButtonModule,
                        MatLegacyCardModule,
                        MatLegacyFormFieldModule,
                        MatIconModule,
                        MatLegacyInputModule,
                        MatLegacyPaginatorModule,
                        MatLegacyTabsModule,
                        MatLegacyProgressSpinnerModule,
                        MatSortModule,
                        MatLegacyTableModule,
                    ],
                    exports: [...COMPONENTS],
                }]
        }], null, null);
})();
(function () {
    (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(DsModule, { declarations: [DsAlertBannerComponent,
            DsButtonComponent,
            DsAccountCardComponent,
            DsCurrencyInputComponent,
            DsStatementTabsComponent,
            DsTransactionTableComponent], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            MatLegacyButtonModule,
            MatLegacyCardModule,
            MatLegacyFormFieldModule,
            MatIconModule,
            MatLegacyInputModule,
            MatLegacyPaginatorModule,
            MatLegacyTabsModule,
            MatLegacyProgressSpinnerModule,
            MatSortModule,
            MatLegacyTableModule], exports: [DsAlertBannerComponent,
            DsButtonComponent,
            DsAccountCardComponent,
            DsCurrencyInputComponent,
            DsStatementTabsComponent,
            DsTransactionTableComponent] });
})();

class DsThemeService {
    constructor() {
        this.mode$ = new BehaviorSubject('light');
    }
    get changes() {
        return this.mode$.asObservable();
    }
    get current() {
        return this.mode$.value;
    }
    setMode(mode) {
        const root = document.documentElement;
        root.classList.remove('bofa-theme--light', 'bofa-theme--dark', 'bofa-theme--high-contrast');
        root.classList.add(`bofa-theme--${mode}`);
        this.mode$.next(mode);
    }
}
DsThemeService.ɵfac = function DsThemeService_Factory(t) { return new (t || DsThemeService)(); };
DsThemeService.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: DsThemeService, factory: DsThemeService.ɵfac, providedIn: 'root' });
(function () {
    (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(DsThemeService, [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], null, null);
})();

/*
 * Public API surface of @bofa/ds
 *
 * Consumed by downstream retail banking applications. Anything exported here is a
 * compatibility contract: removals and signature changes break consumer builds.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DsAccountCardComponent, DsAlertBannerComponent, DsButtonComponent, DsCurrencyInputComponent, DsModule, DsStatementTabsComponent, DsThemeService, DsTransactionTableComponent };
//# sourceMappingURL=bofa-ds.mjs.map
