/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@bofa/ds" />
export * from './public-api';
//# sourceMappingURL=bofa-ds.d.ts.map