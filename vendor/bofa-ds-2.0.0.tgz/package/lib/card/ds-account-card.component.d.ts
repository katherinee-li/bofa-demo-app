import * as i0 from "@angular/core";
export declare class DsAccountCardComponent {
    accountName: string;
    accountNumber: string;
    balance: number;
    currencyCode: string;
    get maskedNumber(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsAccountCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsAccountCardComponent, "bofa-account-card", never, { "accountName": "accountName"; "accountNumber": "accountNumber"; "balance": "balance"; "currencyCode": "currencyCode"; }, {}, never, ["*", "[cardActions]"], false, never>;
}
//# sourceMappingURL=ds-account-card.component.d.ts.map