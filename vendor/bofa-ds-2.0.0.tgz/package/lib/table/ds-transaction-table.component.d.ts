import { AfterViewInit, OnChanges, SimpleChanges } from '@angular/core';
import { MatLegacyPaginator as MatPaginator } from '@angular/material/legacy-paginator';
import { MatSort } from '@angular/material/sort';
import { MatLegacyTableDataSource as MatTableDataSource } from '@angular/material/legacy-table';
import * as i0 from "@angular/core";
export interface DsTransaction {
    postedAt: string;
    description: string;
    category: string;
    amount: number;
}
export declare class DsTransactionTableComponent implements OnChanges, AfterViewInit {
    transactions: DsTransaction[];
    displayedColumns: string[];
    sort?: MatSort;
    paginator?: MatPaginator;
    readonly dataSource: MatTableDataSource<DsTransaction>;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsTransactionTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsTransactionTableComponent, "bofa-transaction-table", never, { "transactions": "transactions"; "displayedColumns": "displayedColumns"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=ds-transaction-table.component.d.ts.map