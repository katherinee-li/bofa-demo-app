import * as i0 from "@angular/core";
import * as i1 from "./alert/ds-alert-banner.component";
import * as i2 from "./button/ds-button.component";
import * as i3 from "./card/ds-account-card.component";
import * as i4 from "./form/ds-currency-input.component";
import * as i5 from "./tabs/ds-statement-tabs.component";
import * as i6 from "./table/ds-transaction-table.component";
import * as i7 from "@angular/common";
import * as i8 from "@angular/forms";
import * as i9 from "@angular/material/button";
import * as i10 from "@angular/material/card";
import * as i11 from "@angular/material/form-field";
import * as i12 from "@angular/material/icon";
import * as i13 from "@angular/material/input";
import * as i14 from "@angular/material/paginator";
import * as i15 from "@angular/material/progress-spinner";
import * as i16 from "@angular/material/sort";
import * as i17 from "@angular/material/table";
import * as i18 from "@angular/material/tabs";
export declare class DsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DsModule, [typeof i1.DsAlertBannerComponent, typeof i2.DsButtonComponent, typeof i3.DsAccountCardComponent, typeof i4.DsCurrencyInputComponent, typeof i5.DsStatementTabsComponent, typeof i6.DsTransactionTableComponent], [typeof i7.CommonModule, typeof i8.FormsModule, typeof i8.ReactiveFormsModule, typeof i9.MatButtonModule, typeof i10.MatCardModule, typeof i11.MatFormFieldModule, typeof i12.MatIconModule, typeof i13.MatInputModule, typeof i14.MatPaginatorModule, typeof i15.MatProgressSpinnerModule, typeof i16.MatSortModule, typeof i17.MatTableModule, typeof i18.MatTabsModule], [typeof i1.DsAlertBannerComponent, typeof i2.DsButtonComponent, typeof i3.DsAccountCardComponent, typeof i4.DsCurrencyInputComponent, typeof i5.DsStatementTabsComponent, typeof i6.DsTransactionTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DsModule>;
}
