import * as i0 from '@angular/core';
import { EventEmitter, OnChanges, AfterViewInit, SimpleChanges } from '@angular/core';
import * as i8 from '@angular/forms';
import { ControlValueAccessor } from '@angular/forms';
import * as i14 from '@angular/material/paginator';
import { MatPaginator } from '@angular/material/paginator';
import * as i16 from '@angular/material/sort';
import { MatSort } from '@angular/material/sort';
import * as i17 from '@angular/material/table';
import { MatTableDataSource } from '@angular/material/table';
import * as i7 from '@angular/common';
import * as i9 from '@angular/material/button';
import * as i10 from '@angular/material/card';
import * as i11 from '@angular/material/form-field';
import * as i12 from '@angular/material/icon';
import * as i13 from '@angular/material/input';
import * as i15 from '@angular/material/progress-spinner';
import * as i18 from '@angular/material/tabs';
import { Observable } from 'rxjs';

type DsAlertSeverity = 'info' | 'warning' | 'critical' | 'success';
declare class DsAlertBannerComponent {
    severity: DsAlertSeverity;
    title?: string;
    dismissible: boolean;
    dismissed: EventEmitter<void>;
    get icon(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsAlertBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsAlertBannerComponent, "bofa-alert-banner", never, { "severity": { "alias": "severity"; "required": false; }; "title": { "alias": "title"; "required": false; }; "dismissible": { "alias": "dismissible"; "required": false; }; }, { "dismissed": "dismissed"; }, never, ["*"], false, never>;
}

type DsButtonVariant = 'primary' | 'secondary' | 'danger';
declare class DsButtonComponent {
    variant: DsButtonVariant;
    disabled: boolean;
    loading: boolean;
    pressed: EventEmitter<MouseEvent>;
    get materialColor(): 'primary' | 'accent' | 'warn';
    static ɵfac: i0.ɵɵFactoryDeclaration<DsButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsButtonComponent, "bofa-button", never, { "variant": { "alias": "variant"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, { "pressed": "pressed"; }, never, ["*"], false, never>;
}

declare class DsAccountCardComponent {
    accountName: string;
    accountNumber: string;
    balance: number;
    currencyCode: string;
    get maskedNumber(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsAccountCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsAccountCardComponent, "bofa-account-card", never, { "accountName": { "alias": "accountName"; "required": false; }; "accountNumber": { "alias": "accountNumber"; "required": false; }; "balance": { "alias": "balance"; "required": false; }; "currencyCode": { "alias": "currencyCode"; "required": false; }; }, {}, never, ["*", "[cardActions]"], false, never>;
}

declare class DsCurrencyInputComponent implements ControlValueAccessor {
    label: string;
    hint?: string;
    value: number | null;
    disabled: boolean;
    private onChange;
    onTouched: () => void;
    writeValue(value: number | null): void;
    registerOnChange(fn: (value: number | null) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onInput(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsCurrencyInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsCurrencyInputComponent, "bofa-currency-input", never, { "label": { "alias": "label"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; }, {}, never, never, false, never>;
}

interface DsStatementPeriod {
    label: string;
    periodId: string;
    documentCount: number;
}
/** Statement period switcher. */
declare class DsStatementTabsComponent {
    periods: DsStatementPeriod[];
    selectedIndex: number;
    periodChanged: EventEmitter<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsStatementTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsStatementTabsComponent, "bofa-statement-tabs", never, { "periods": { "alias": "periods"; "required": false; }; "selectedIndex": { "alias": "selectedIndex"; "required": false; }; }, { "periodChanged": "periodChanged"; }, never, ["*"], false, never>;
}

interface DsTransaction {
    postedAt: string;
    description: string;
    category: string;
    amount: number;
}
declare class DsTransactionTableComponent implements OnChanges, AfterViewInit {
    transactions: DsTransaction[];
    displayedColumns: string[];
    sort?: MatSort;
    paginator?: MatPaginator;
    readonly dataSource: MatTableDataSource<DsTransaction, MatPaginator>;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsTransactionTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsTransactionTableComponent, "bofa-transaction-table", never, { "transactions": { "alias": "transactions"; "required": false; }; "displayedColumns": { "alias": "displayedColumns"; "required": false; }; }, {}, never, never, false, never>;
}

declare class DsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DsModule, [typeof DsAlertBannerComponent, typeof DsButtonComponent, typeof DsAccountCardComponent, typeof DsCurrencyInputComponent, typeof DsStatementTabsComponent, typeof DsTransactionTableComponent], [typeof i7.CommonModule, typeof i8.FormsModule, typeof i8.ReactiveFormsModule, typeof i9.MatButtonModule, typeof i10.MatCardModule, typeof i11.MatFormFieldModule, typeof i12.MatIconModule, typeof i13.MatInputModule, typeof i14.MatPaginatorModule, typeof i15.MatProgressSpinnerModule, typeof i16.MatSortModule, typeof i17.MatTableModule, typeof i18.MatTabsModule], [typeof DsAlertBannerComponent, typeof DsButtonComponent, typeof DsAccountCardComponent, typeof DsCurrencyInputComponent, typeof DsStatementTabsComponent, typeof DsTransactionTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DsModule>;
}

type DsThemeMode = 'light' | 'dark' | 'high-contrast';
declare class DsThemeService {
    private readonly mode$;
    get changes(): Observable<DsThemeMode>;
    get current(): DsThemeMode;
    setMode(mode: DsThemeMode): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DsThemeService>;
}

export { DsAccountCardComponent, DsAlertBannerComponent, DsButtonComponent, DsCurrencyInputComponent, DsModule, DsStatementTabsComponent, DsThemeService, DsTransactionTableComponent };
export type { DsAlertSeverity, DsButtonVariant, DsStatementPeriod, DsThemeMode, DsTransaction };
