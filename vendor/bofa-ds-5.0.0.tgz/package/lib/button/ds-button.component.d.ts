import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export type DsButtonVariant = 'primary' | 'secondary' | 'danger';
export declare class DsButtonComponent {
    variant: DsButtonVariant;
    disabled: boolean;
    loading: boolean;
    pressed: EventEmitter<MouseEvent>;
    get materialColor(): 'primary' | 'accent' | 'warn';
    static ɵfac: i0.ɵɵFactoryDeclaration<DsButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsButtonComponent, "bofa-button", never, { "variant": { "alias": "variant"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, { "pressed": "pressed"; }, never, ["*"], false, never>;
}
