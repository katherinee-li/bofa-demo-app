import * as i0 from "@angular/core";
export declare class DsAccountCardComponent {
    accountName: string;
    accountNumber: string;
    balance: number;
    currencyCode: string;
    get maskedNumber(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsAccountCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DsAccountCardComponent, "bofa-account-card", never, { "accountName": { "alias": "accountName"; "required": false; }; "accountNumber": { "alias": "accountNumber"; "required": false; }; "balance": { "alias": "balance"; "required": false; }; "currencyCode": { "alias": "currencyCode"; "required": false; }; }, {}, never, ["*", "[cardActions]"], false, never>;
}
