import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export type DsThemeMode = 'light' | 'dark' | 'high-contrast';
export declare class DsThemeService {
    private readonly mode$;
    get changes(): Observable<DsThemeMode>;
    get current(): DsThemeMode;
    setMode(mode: DsThemeMode): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DsThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DsThemeService>;
}
